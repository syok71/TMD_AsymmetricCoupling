function [M,C,K,f,Eivt] = makeMCK_TMD(m,c,k,mt,ct,kt)
% 1        ~   ndof : story drift
% ndof+1   ~ 2*ndof : absolute acceleration
% 2*ndof+1 ~ 3*ndof : absolute displacement
% 3*ndof+1 ~ 4*ndof : relative velocity between floors
% 4*ndof+1 ~ 5*ndof : absolute velocity
[n,n]=size(m);
M = m;
K = k;
C = c;

M(n+1,n+1) = mt;
K(n+1,n+1) = kt;
K(n+1,n) = -kt;
K(n,n+1) = -kt;
K(n,n) = k(end,end)+kt;
C(n+1,n+1) = ct;
C(n+1,n) = -ct;
C(n,n+1) = -ct;
C(n,n) = c(end,end)+ct;

[w,f,Eivt]=eigkm(K,M); % w���ް� Eivt ���̰պ�Ÿ


end
