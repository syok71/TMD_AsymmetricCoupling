clear all;close all;
%% System parameters
%% Origin
ndof=10;
h = 2.5; % H=2.5m
m = 4.5e5*ones(ndof,1); % mass : kg
damp_zi = [0.02*ones(ndof,1)]; % damping ratio : 2%
k = 1.2e9*ones(ndof,1); % stiffness : N/m

[Mmat,Cmat,Kmat,fn,phin,Mn,Cn,Kn,Mn_star,Hn_star]=makeMCK(m,k,damp_zi,h);

%% TMD
Mass_Ctrb_Ratio = Mn_star'/sum(m)*100;

M1 = Mn_star(1);
K1 = (2*pi*fn(1))^2*M1;
C1 = 4*pi*damp_zi(1)*fn(1)*M1;

%% Original Bld.
Wsys = [0.1:0.01:50]';
Freqsys = Wsys/(2*pi);

[A0,Bw,C0y,D0y]=genst_MDOF(M1,C1,K1);
syst = ss(A0,Bw,C0y,D0y);    

Hw = freqresp(syst,Wsys);
Hsys = squeeze(Hw);
PwSpec_Org = (abs(Hsys)).^2;
max_resp = max(PwSpec_Org,[],1);
%% TMD Design
mu = 0.03;
freq_ratio = 1/(1+mu);
xi_ratio = sqrt(3*mu/(8*(1+mu)));

mT = mu*M1;
kT = mT*(2*pi*freq_ratio*fn(1))^2;
cT = 2*xi_ratio*(sqrt(kT/mT))*mT;

[Mmat_TMD,Cmat_TMD,Kmat_TMD,fn_TMD,phin_TMD]=makeMCK_TMD(M1,C1,K1,mT,cT,kT);

[A0_TMD,Bw_TMD,C0y_TMD,D0y_TMD]=genst_MDOF_TMD(Mmat_TMD,Cmat_TMD,Kmat_TMD);
syst_TMD = ss(A0_TMD,Bw_TMD,C0y_TMD,D0y_TMD);

Hw_TMD = freqresp(syst_TMD,Wsys);
Hsys_TMD = squeeze(Hw_TMD)';
PwSpec_TMD = (abs(Hsys_TMD)).^2;
max_resp_TMD = max(PwSpec_TMD,[],1);
    
Max_Resp_TMD(1) = max_resp_TMD(1);
Max_Resp_TMD(2) = max_resp_TMD(1);
Max_Resp_TMD(3) = max_resp_TMD(2);

save STMD_DSG_M0
