function [A0,B0u,C0y,D0y] = genst_MDOF(m,c,k)

[n,n]=size(m);
O1=zeros(n,n);
O3=zeros(n,1);
I=eye(n,n);
iM=inv(m);
A0=[O1 I;
    -iM*k -iM*c];


B0u=[O3; -ones(n,1)];

C0y=[eye(n),zeros(n,n)];
D0y=zeros(n,1);


