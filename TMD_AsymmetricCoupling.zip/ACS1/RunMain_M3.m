clear all;close all;
warning('off','MATLAB:dispatcher:InexactCaseMatch')
wState = warning('off','MATLAB:dispatcher:pathWwarning');

%% Original Buildings' Responses
load(['../ICS/STMD_DSG_M0.mat'],'Max_Resp_TMD','M1','C1','K1','damp_zi','fn','mu');
params.Max_Resp_TMD = Max_Resp_TMD;
%% Structural Properties
params.M1 = M1; % [kg]
params.zi_s = damp_zi(1); % [%]
params.fs = fn(1); % [Hz]

params.K1 = K1; %[N/m]
params.C1 = C1;
%--------------------------------------------------------------------------
A = [];b = [];Aeq = [0,0,0,0,1,1];beq = [0.06];NONLCON = [];
%--------------------------------------------------------------------------
Nvars = 6;
LB = [0.5,0.05,0.01,0.01,0.,0.005];
UB = [2.0,0.4,0.2,0.1,0.06,0.06];
x0 = 0.5*(LB+UB);
%--------------------------------------------------------------------------
Num_Pop = 500;
Num_Gen = 50000;
Num_Same = Num_Gen*0.1;

options = gaoptimset(...
    'PopulationType','doubleVector','PopulationSize',Num_Pop...
    ,'InitialPopulation',x0,'Generations',Num_Gen...
    ,'StallGenLimit',Num_Same,'TolCon',1e-12...
    ,'display','off','Vectorized','off'...
    ,'UseParallel','always');

[x,fval,exitflag,output,population,scores]...
    = gamultiobj(@(x)evaluate_objective_M3(x,params),Nvars,A,b,Aeq,beq,LB,UB,options);

%% sort
x_nostroke = x;
fval_nostroke = fval;
[fval_nostroke_F, idx_nostroke]=sortrows(fval_nostroke,1);
x_nostroke_F = x_nostroke(idx_nostroke,:);

eval(['save RunMain_M3_DsgResult.mat']);

