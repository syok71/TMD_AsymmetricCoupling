function [Mmat,Cmat,Kmat] = Model3(M1,C1,K1,mT,cT,kT,md,cd,kd)

Mmat = diag([M1,M1,mT,md]);
Cmat = [C1+cd,0,0,-cd;
    0,C1+cd+cT,-cT,-cd;
    0,-cT,cT,0;
    -cd,-cd,0,cd+cd];
Kmat = [K1+kd,0,0,-kd;
    0,K1+kd+kT,-kT,-kd;
    0,-kT,kT,0;
    -kd,-kd,0,kd+kd];
