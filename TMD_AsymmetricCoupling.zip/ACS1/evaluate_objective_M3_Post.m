function [max_resp_new,PwSpec,Freqsys,wn,phin] = evaluate_objective_M3_Post(x,params)

M1 = params.M1;
zi_s = params.zi_s;
fs = params.fs;

K1 = params.K1;
C1 = params.C1;

mT = x(5)*M1;
fT = x(1)*fs;
kT = (2*pi*fT)^2*mT;
cT = 4*pi*x(2)*fT*mT;
cd = x(3)*C1;
kd = x(4)*K1;
md = x(6)*M1;

if mT == 0
    ce=cd;ke=kd;
    [Mmat,Cmat,Kmat] = Model5(M1,C1,K1,md,cd,kd,ce,ke);
    [PwSpec,Freqsys] = Resp_M5(Mmat,Cmat,Kmat);
else
    [Mmat,Cmat,Kmat] = Model3(M1,C1,K1,mT,cT,kT,md,cd,kd);
    [PwSpec,Freqsys] = Resp_M3(Mmat,Cmat,Kmat);
end

[wn,fn,phin] = eigkm(Kmat,Mmat);

max_resp = max(PwSpec,[],2);

if x(5) == 0
    U_S1 = max_resp(1);
    U_S2 = max_resp(2);
    U_S12 = max_resp(3);
    U_TMD = 0;
    U_S1T = max_resp(4);
    U_S2T = max_resp(5);
else
    U_S1 = max_resp(1);
    U_S2 = max_resp(2);
    U_S12 = max_resp(3);
    U_TMD = max_resp(4);
    U_S1T = max_resp(5);
    U_S2T = max_resp(6);
end

max_resp_new = [U_S1,U_S2,U_S12,U_TMD,U_S1T,U_S2T];


