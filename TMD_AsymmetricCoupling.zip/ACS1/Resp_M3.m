function [PwSpec, Freqsys] = Resp_M3(Mmat,Cmat,Kmat)

%% State-Space System
iMmat = inv(Mmat);
Asysmat = [zeros(4),eye(4);
    -iMmat*Kmat,-iMmat*Cmat];
Bsysmat = [zeros(4,1);-ones(4,1)];
Csysmat = [[1,0,0,0;0,1,0,0;-1,1,0,0;0,-1,1,0;-1,0,0,1;0,1,0,-1],zeros(6,4)];
Dsysmat = zeros(6,1);
Sys_TMD = ss(Asysmat,Bsysmat,Csysmat,Dsysmat);

Wsys = [0.1:0.01:50];
Hw = freqresp(Sys_TMD,Wsys);
Freqsys = Wsys/(2*pi);Hsys = squeeze(Hw);PwSpec = (abs(Hsys)).^2;
max_resp = max(PwSpec,[],2);
