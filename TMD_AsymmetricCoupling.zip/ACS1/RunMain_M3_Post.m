clear all; close all;

load(['../ICS/STMD_DSG_M0.mat'],'mT','cT','kT','Max_Resp_TMD');

load(['RunMain_M3_DsgResult.mat'],'fval_nostroke_F','x_nostroke_F','params'); % ???????? MOGA

M1 = params.M1;
K1 = params.K1;
C1 = params.C1;
fs = params.fs;

mT_nostroke = M1*x_nostroke_F(:,5);
fT_nostroke = fs*x_nostroke_F(:,1);
cT_nostroke = 4*pi*x_nostroke_F(:,2).*fT_nostroke.*mT_nostroke;
kT_nostroke = (2*pi.*fT_nostroke).^2.*mT_nostroke;
md_nostroke = M1*x_nostroke_F(:,6);
cd_nostroke = C1*x_nostroke_F(:,3);
kd_nostroke = K1*x_nostroke_F(:,4);

for ii = 1:length(fval_nostroke_F)
    
    [max_resp_nostroke,PwSpec_nostroke,Freqsys_nostroke,WS,PHIS] = evaluate_objective_M3_Post(x_nostroke_F(ii,:),params);
    max_resp_nostroke_F(:,ii) = max_resp_nostroke';
    FREQS(:,ii) = WS/2/pi;
    
end

max_resp_biTMD_M3_nostroke = max_resp_nostroke_F;

save RunMain_M3_PostResult.mat

