function [Mmat,Cmat,Kmat] = Model5(M1,C1,K1,md,cd,kd,ce,ke)

Mmat = diag([M1,M1,md]);
Cmat = [C1+cd,0,-cd;
    0,C1+ce,-ce;
    -cd,-ce,cd+ce];
Kmat = [K1+kd,0,-kd;
    0,K1+ke,-ke;
    -kd,-ke,kd+ke];

