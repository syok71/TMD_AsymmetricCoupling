function [PwSpec,Freqsys] = Resp_M5(Mmat,Cmat,Kmat)

%% State-Space System
iMmat = inv(Mmat);
Asysmat = [zeros(3),eye(3);
    -iMmat*Kmat,-iMmat*Cmat];
Bsysmat = [zeros(3,1);-ones(3,1)];
Csysmat = [[1,0,0;0,1,0;-1,1,0;-1,0,1;0,1,-1],zeros(5,3)];
Dsysmat = zeros(5,1);
Sys_TMD = ss(Asysmat,Bsysmat,Csysmat,Dsysmat);

Wsys = [0.1:0.01:50];
Hw = freqresp(Sys_TMD,Wsys);
Freqsys = Wsys/(2*pi);Hsys = squeeze(Hw);PwSpec = (abs(Hsys)).^2;

