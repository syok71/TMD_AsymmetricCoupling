clear all; close all;

load(['../ICS/STMD_DSG_M0.mat'],'mT','cT','kT','Max_Resp_TMD');

load(['RunMain_M5_DsgResult.mat'],'fval_nostroke_F','x_nostroke_F','params'); % ???????? MOGA

M1 = params.M1;
K1 = params.K1;
C1 = params.C1;
muT = params.muT;

cd = C1*x_nostroke_F(1);
kd = x_nostroke_F(2)*K1;
md = muT*M1;
ce = x_nostroke_F(3)*C1;
ke = x_nostroke_F(4)*K1;

for ii = 1:length(fval_nostroke_F)
    
    [max_resp_nostroke,PwSpec_nostroke,Freqsys_nostroke,WS,PHIS] = evaluate_objective_M5_Post(x_nostroke_F(ii,:),params);
    max_resp_nostroke_F(:,ii) = max_resp_nostroke';
    FREQS(:,ii) = WS/2/pi;
    
end

max_resp_biTMD_M5_nostroke = max_resp_nostroke_F;

save RunMain_M5_PostResult.mat
