function f = evaluate_objective_M5(x,params)

M1 = params.M1;
zi_s = params.zi_s;
fs = params.fs;
muT = params.muT;

K1 = params.K1;
C1 = params.C1;

cd = x(1)*C1;
kd = x(2)*K1;
md = muT*M1;
ce = x(3)*C1;
ke = x(4)*K1;

[Mmat,Cmat,Kmat] = Model5(M1,C1,K1,md,cd,kd,ce,ke);
[PwSpec,Freqsys] = Resp_M5(Mmat,Cmat,Kmat);

max_resp = max(PwSpec,[],2);

U_S1 = max_resp(1);
U_S2 = max_resp(2);

max_resp_o = params.Max_Resp_TMD;
U_S1_o = max_resp_o(1);
U_S2_o = max_resp_o(2);

f(1,1) = U_S1/U_S1_o + 1e10*max(0,U_S1/U_S1_o-1) + 1e10*max(0,U_S2/U_S2_o-1);
f(2,1) = U_S2/U_S2_o + 1e10*max(0,U_S1/U_S1_o-1) + 1e10*max(0,U_S2/U_S2_o-1);
