function [max_resp,PwSpec,Freqsys,wn,phin] = evaluate_objective_M5_Post(x,params)

M1 = params.M1;
zi_s = params.zi_s;
fs = params.fs;
muT = params.muT;

K1 = params.K1;
C1 = params.C1;

cd = x(1)*C1;
kd = x(2)*K1;
md = muT*M1;
ce = x(3)*C1;
ke = x(4)*K1;

[Mmat,Cmat,Kmat] = Model5(M1,C1,K1,md,cd,kd,ce,ke);
[PwSpec,Freqsys] = Resp_M5(Mmat,Cmat,Kmat);

[wn,fn,phin] = eigkm(Kmat,Mmat);

max_resp = max(PwSpec,[],2);

% U_S1 = max_resp(1);
% U_S2 = max_resp(2);
% U_S12 = max_resp(3);
% U_TMDL = max_resp(4);
% U_TMDR = max_resp(5);
% U_TMD_Stroke = max(abs([U_TMDL,U_TMDR]));


